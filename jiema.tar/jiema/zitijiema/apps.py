from django.apps import AppConfig


class ZitijiemaConfig(AppConfig):
    name = 'zitijiema'
